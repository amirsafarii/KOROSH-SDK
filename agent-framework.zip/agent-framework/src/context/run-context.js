import { newRunId } from '../utils/id.js';
import { nowMs } from '../utils/time.js';

/**
 * RunContext — per-run execution identity and ambient data.
 *
 * Strictly separated from conversation history / persisted state: it answers
 * "which run, which agent, what ambient info", never "what has been said".
 * Handed to tools as a read-only summary; the loop keeps its own state.
 */
export class RunContext {
  get runId() {
    return this.#runId;
  }

  get agent() {
    return this.#agent;
  }

  /** Caller-supplied correlation data (deep-copied at construction). */
  get metadata() {
    return this.#metadata;
  }

  /** Wall-clock start of the run (epoch ms). */
  get startedAt() {
    return this.#startedAt;
  }

  /**
   * @param {object} options
   * @param {object} options.agent the Agent definition for this run
   * @param {string} [options.runId] pre-assigned run id (else generated)
   * @param {object} [options.metadata] caller correlation data
   */
  constructor({ agent, runId = newRunId(), metadata = {} }) {
    this.#runId = runId;
    this.#agent = agent;
    this.#metadata = deepFreezeCopy(metadata);
    this.#startedAt = nowMs();
    Object.freeze(this);
  }

  #runId;
  #agent;
  #metadata;
  #startedAt;

  /**
   * Read-only projection handed to tools and model adapters — deliberately
   * narrow so future persistence/session layers can extend without breaking
   * consumers.
   */
  describe() {
    return {
      runId: this.#runId,
      agentName: this.#agent?.name ?? null,
      metadata: this.#metadata,
    };
  }
}

function deepFreezeCopy(value) {
  if (value === null || typeof value !== 'object') {
    return value;
  }
  const copy = Array.isArray(value) ? [...value] : { ...value };
  for (const key of Object.keys(copy)) {
    copy[key] = deepFreezeCopy(copy[key]);
  }
  return Object.freeze(copy);
}
