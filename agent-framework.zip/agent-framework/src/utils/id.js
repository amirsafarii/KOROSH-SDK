import { createHash } from 'node:crypto';

let counter = 0;
let lastTs = 0;

// Process-wide random suffix — distinguishes this process from any other.
const suffix = createHash('sha1')
  .update(`${process.pid}:${Date.now()}:${Math.random()}`)
  .digest('hex')
  .slice(0, 6);

/**
 * Monotonic, collision-safe ID factory.
 *
 * Deterministic per-process ordering: IDs generated in this process always
 * compare in generation order (same-ms generations are disambiguated by an
 * incrementing counter; a clock regression rotates the suffix so a counter
 * value never re-encodes an earlier instant).
 */
export function createId(prefix) {
  const ts = Date.now();
  let sfx = suffix;
  if (ts < lastTs) {
    // Clock moved backwards — rotate suffix so ordering never repeats.
    sfx = createHash('sha1').update(`regress:${ts}`).digest('hex').slice(0, 6);
    counter = 0;
  }
  if (ts === lastTs) {
    counter += 1;
  } else {
    lastTs = ts;
    counter = 0;
  }
  return `${prefix}_${ts.toString(36)}${counter.toString(36)}${sfx}`;
}

export const newRunId = () => createId('run');
export const newTurnId = () => createId('turn');
export const newToolCallId = () => createId('call');
export const newEventId = () => createId('evt');
