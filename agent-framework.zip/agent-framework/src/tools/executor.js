import { ToolNotFoundError } from '../errors.js';
import { toToolMessage } from './result.js';
import { SequentialStrategy } from './sequential-strategy.js';

/**
 * ToolExecutor — the loop-facing facade over the tool pipeline:
 *
 *   Lookup → Validate → Execute (via ExecutionStrategy) → Normalize
 *
 * Produces, for every model tool_call, BOTH artifacts downstream needs:
 *   - ToolExecution  {call, status, output?, error?}      (loop bookkeeping)
 *   - internal message {role:'tool', toolCallId, content} (next model input)
 */
export class ToolExecutor {
  /**
   * @param {object} options
   * @param {import('./registry.js').ToolRegistry} options.registry
   * @param {object} [options.strategy] ExecutionStrategy (default Sequential)
   */
  constructor({ registry, strategy }) {
    this.#registry = registry;
    this.#strategy = strategy ?? new SequentialStrategy();
  }

  #registry;
  #strategy;

  get registry() {
    return this.#registry;
  }

  /**
   * Execute every call in `calls` through the configured strategy and
   * normalize outcomes. Never throws for per-call failures — those become
   * `{status:'error'}` entries; only structural misuse throws.
   * @param {Array<{id,name,arguments}>} calls
   * @param {{runContext, signal}} env
   * @returns {Promise<{executions:Array, messages:Array<{role:'tool',toolCallId,content}>}>}
   */
  async executeCalls(calls, { runContext, signal }) {
    if (!Array.isArray(calls) || calls.length === 0) {
      return { executions: [], messages: [] };
    }

    // Fail fast on unknown tools BEFORE running any of them, so a missing
    // tool surfaces deterministically even when a parallel strategy would
    // otherwise race partial executions.
    for (const call of calls) {
      if (!this.#registry.has(call.name)) {
        throw new ToolNotFoundError(`Tool "${call.name}" is not registered.`, {
          toolName: call.name,
          toolCallId: call.id,
        });
      }
    }

    const executions = await this.#strategy.execute(calls, {
      registry: this.#registry,
      runContext,
      signal,
    });

    const messages = executions.map((execution) =>
      toToolMessage({
        toolCallId: execution.call.id,
        toolName: execution.call.name,
        status: execution.status,
        output: execution.output,
        error: execution.error,
      }),
    );
    return { executions, messages };
  }
}
