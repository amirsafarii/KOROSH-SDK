/**
 * Tool-result representation — converts an execution outcome into the
 * standard internal message appended back into the conversation:
 *
 *   { role: 'tool', toolCallId, content }
 *
 * Kept in its own module so the loop stays format-free and a future
 * persistence layer can serialize results without touching loop code.
 */
import { ToolResultError } from '../errors.js';

/**
 * Build the internal tool message for one executed call.
 * @param {object} params
 * @param {string} params.toolCallId id echoed from the model's tool_call
 * @param {string} params.toolName registry name of the executed tool
 * @param {'success'|'error'} params.status executor outcome
 * @param {any} [params.output] tool output when status === 'success'
 * @param {Error} [params.error] typed framework error when status === 'error'
 * @returns {{role:'tool', toolCallId:string, content:string}}
 */
export function toToolMessage({ toolCallId, toolName, status, output, error }) {
  if (typeof toolCallId !== 'string' || toolCallId.length === 0) {
    throw new ToolResultError('toToolMessage requires "toolCallId".', { toolName });
  }
  if (status !== 'success' && status !== 'error') {
    throw new ToolResultError(`toToolMessage requires status success|error, got "${status}".`, {
      toolCallId,
      toolName,
    });
  }

  const content =
    status === 'success'
      ? serializeOutput(output)
      : serializeError(error);

  return Object.freeze({ role: 'tool', toolCallId, content });
}

function serializeOutput(output) {
  if (typeof output === 'string') {
    return output;
  }
  try {
    return JSON.stringify(output ?? null);
  } catch (cause) {
    throw new ToolResultError('Tool output is not serializable.', { cause });
  }
}

function serializeError(error) {
  const message = error instanceof Error ? error.message : String(error);
  return JSON.stringify({ error: message });
}
