/**
 * ExecutionStrategy — HOW a turn's tool calls run, decided outside the loop.
 *
 * Phase 1 ships SequentialStrategy only; ParallelStrategy can be added later
 * without touching AgentLoop because the loop depends solely on this
 * contract:
 *
 *   async execute(calls, context) => ToolExecution[]
 *
 *   calls:    [{id, name, arguments}]  (validated model tool_calls)
 *   context:  { signal, registry, runContext, logger }
 *   returns:  array of { call, status:'success'|'error', output?, error? }
 *             — one entry per input call, same order as `calls`.
 */
import {
  ToolError,
  ToolExecutionError,
  ToolNotFoundError,
} from '../errors.js';

/** Shared per-call machinery: lookup → validate → execute. Strategy orders the calls. */
export function executeSingleCall(call, { registry, runContext, signal }) {
  const tool = registry.get(call.name);
  if (tool === undefined) {
    throw new ToolNotFoundError(`Tool "${call.name}" is not registered.`, {
      toolName: call.name,
      toolCallId: call.id,
    });
  }

  const validation = validateArguments(call.arguments, tool.parameters);
  if (!validation.valid) {
    throw new ToolValidationError(
      `Tool "${call.name}" received invalid arguments: ${validation.message}`,
      { toolName: call.name, toolCallId: call.id },
    );
  }

  let output;
  try {
    output = tool.execute(deepCopyArgs(call.arguments), runContext.describe(), { signal });
    // Tools may be sync or async — normalize through Promise.resolve so the
    // strategy contract stays uniformly awaitable.
  } catch (cause) {
    throw wrapToolFailure(cause, call);
  }
  return Promise.resolve(output).catch((cause) => wrapToolFailure(cause, call));
}

function wrapToolFailure(cause, call) {
  return new ToolExecutionError(
    `Tool "${call.name}" failed: ${cause?.message ?? String(cause)}`,
    {
      toolName: call.name,
      toolCallId: call.id,
      cause,
    },
  );
}

/**
 * Minimal structural validation against the tool's schema object. Supports
 * `type`, `required` and `properties.<key>.type` — deliberately tiny: richer
 * validation belongs to user-supplied schemas/tools (Phase 13 guardrails),
 * not to Core.
 */
export function validateArguments(args, parameters) {
  if (!isPlainObject(parameters)) {
    return { valid: true };
  }
  if ((parameters.type ?? 'object') !== 'object') {
    return { valid: true }; // non-object schemas are out of Core's scope
  }
  if (!isPlainObject(args)) {
    return { valid: false, message: 'arguments must be an object' };
  }

  for (const key of Array.isArray(parameters.required) ? parameters.required : []) {
    if (!(key in args)) {
      return { valid: false, message: `missing required argument "${key}"` };
    }
  }

  const properties = isPlainObject(parameters.properties) ? parameters.properties : {};
  for (const [key, spec] of Object.entries(properties)) {
    if (!(key in args) || !isPlainObject(spec)) continue;
    const actual = args[key];
    const expected = typeof spec.type === 'string' ? spec.type : null;
    if (expected && !matchesType(actual, expected)) {
      return {
        valid: false,
        message: `argument "${key}" must be ${expected}`,
      };
    }
  }
  return { valid: true };
}

function matchesType(value, expected) {
  switch (expected) {
    case 'string':
      return typeof value === 'string';
    case 'number':
      return typeof value === 'number' && Number.isFinite(value);
    case 'boolean':
      return typeof value === 'boolean';
    case 'object':
      return isPlainObject(value);
    case 'array':
      return Array.isArray(value);
    case 'null':
      return value === null;
    default:
      return true; // unknown type keywords never reject
  }
}

function deepCopyArgs(args) {
  return structuredClone(args);
}

function isPlainObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

export { ToolError };
