import { executeSingleCall } from './strategy.js';

/**
 * SequentialStrategy — Phase 1 default: run each tool call one after another
 * in model-requested order. Implements the ExecutionStrategy contract; the
 * loop never hard-codes this choice.
 */
export class SequentialStrategy {
  /**
   * @param {Array<{id,name,arguments}>} calls
   * @param {{registry, runContext, signal, logger}} context
   * @returns {Promise<Array<{call,status,output?,error?}>>}
   */
  async execute(calls, { registry, runContext, signal }) {
    const results = [];
    for (const call of calls) {
      try {
        const output = await executeSingleCall(call, { registry, runContext, signal });
        results.push({ call, status: 'success', output });
      } catch (cause) {
        // Typed tool errors carry toolName/toolCallId — preserve them whole.
        results.push({ call, status: 'error', error: cause });
      }
    }
    return results;
  }
}
