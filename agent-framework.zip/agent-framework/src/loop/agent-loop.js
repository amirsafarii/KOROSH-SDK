import { ToolRegistry } from '../tools/registry.js';
import {
  InputError,
  LoopError,
  MaxTurnsError,
  ModelError,
} from '../errors.js';
import { assertModelResult } from '../model/types.js';
import { normalizeInput } from '../input/normalizer.js';
import { ToolExecutor } from '../tools/executor.js';
import { RunContext } from '../context/run-context.js';
import { EventBus, RunEvents } from '../events/bus.js';
import { deepCopy } from '../utils/objects.js';
import { Turn } from './turn.js';

export const DEFAULT_MAX_TURNS = 10;

/**
 * AgentLoop — the deterministic execution engine.
 *
 * Implements exactly one cycle shape:
 *   User Input → Prepare Run → Prepare Turn → Model Call → Analyze Result
 *     → Final → Finish
 *     or → Tool Calls → Validate/Resolve/Execute/Normalize → Append Results
 *          → next Model Call
 *
 * Isolation: every `run()` call builds its own conversation copy, its own
 * RunContext and its own executor view — concurrent runs share nothing
 * mutable. The loop is provider-agnostic: it only knows NormalizedModelResult.
 */
export class AgentLoop {
  /**
   * @param {object} options
   * @param {import('../core/agent.js').Agent} options.agent validated definition
   * @param {import('../tools/registry.js').ToolRegistry} [options.registry]
   *        defaults to a registry built from agent.tools
   * @param {object} [options.strategy] ExecutionStrategy override (tests / future ParallelStrategy)
   * @param {number} [options.maxTurns=DEFAULT_MAX_TURNS] hard loop bound
   * @param {EventBus} [options.events] shared bus (Runner injects one)
   * @param {object} [options.logger] injectable {debug,info,warn,error}
   */
  constructor({ agent, registry, strategy, maxTurns = DEFAULT_MAX_TURNS, events, logger }) {
    if (!agent) {
      throw new LoopError('AgentLoop requires an agent.');
    }
    const resolvedRegistry =
      registry ?? buildRegistryFromAgent(agent);
    this.#executor = new ToolExecutor({ registry: resolvedRegistry, strategy });
    this.#agent = agent;
    this.#maxTurns = validateMaxTurns(maxTurns);
    this.#events = events ?? new EventBus({ logger });
    this.#logger = logger ?? silentLogger;
  }

  #agent;
  #executor;
  #maxTurns;
  #events;
  #logger;

  /** @returns {EventBus} the bus this loop emits lifecycle events on */
  get events() {
    return this.#events;
  }

  get maxTurns() {
    return this.#maxTurns;
  }

  /**
   * Execute one complete run.
   * @param {string|Array|object} input public run input (normalized internally)
   * @param {{signal?: AbortSignal, metadata?: object, runId?: string}} [options]
   * @returns {Promise<RunResult>}
   */
  async run(input, options = {}) {
    // ---- Prepare Run -----------------------------------------------------
    const signal = options.signal ?? null;
    const runContext = new RunContext({
      agent: this.#agent,
      runId: options.runId,
      metadata: options.metadata,
    });
    const runId = runContext.runId;
    const startedAt = runContext.startedAt;

    // Conversation state owned exclusively by THIS run — never mutated after
    // creation except by appending normalized tool results below. Input
    // validation happens before any lifecycle event so malformed input fails
    // fast without emitting a misleading run.started.
    let history;
    try {
      history = normalizeInput(input);
    } catch (cause) {
      throw enrich(cause, { runId });
    }

    this.#events.emit(RunEvents.RUN_STARTED, {
      runId,
      data: { agent: this.#agent.describe(), metadata: runContext.metadata },
    });

    const turns = [];
    try {
      // ---- Turn cycle ----------------------------------------------------
      for (let turnNumber = 1; turnNumber <= this.#maxTurns; turnNumber++) {
        const turn = new Turn({ number: turnNumber, input: deepCopy(history) });
        turns.push(turn);
        this.#events.emit(RunEvents.TURN_STARTED, {
          runId,
          turnId: turn.id,
          data: { number: turn.number },
        });

        // ---- Model Call -----------------------------------------------
        this.#events.emit(RunEvents.MODEL_STARTED, {
          runId,
          turnId: turn.id,
          data: { number: turn.number },
        });
        let modelResult;
        try {
          modelResult = await this.callModel({
            instructions: this.#agent.instructions,
            input: deepCopy(history),
            tools: this.#executor.registry.list().map((tool) => tool.describe()),
            metadata: {
              runId,
              turnNumber: turn.number,
              agentName: this.#agent.name,
            },
            signal,
          });
        } catch (cause) {
          throw enrich(
            cause instanceof ModelError
              ? cause
              : new ModelError('Model adapter failed.', { cause }),
            { runId, turnId: turn.id },
          );
        }
        assertModelResult(modelResult, { runId, turnId: turn.id });
        turn.setModelResult(modelResult);
        this.#events.emit(RunEvents.MODEL_COMPLETED, {
          runId,
          turnId: turn.id,
          data: {
            number: turn.number,
            hasFinal: typeof modelResult.final === 'string',
            toolCallCount: turn.toolCalls.length,
          },
        });

        // ---- Analyze Result -------------------------------------------
        if (typeof modelResult.final === 'string' && turn.toolCalls.length === 0) {
          // ---- Final → Finish -----------------------------------------
          turn.complete();
          this.#events.emit(RunEvents.TURN_COMPLETED, {
            runId,
            turnId: turn.id,
            data: { number: turn.number, status: turn.status },
          });
          const result = buildRunResult({
            runContext,
            status: 'completed',
            output: modelResult.final,
            turns,
            startedAt,
          });
          this.#emitRunCompleted(runId, result);
          return result;
        }

        // ---- Tool Calls: Validate → Resolve → Execute → Normalize ------
        if (turnNumber < this.#maxTurns && turn.toolCalls.length > 0) {
          const { executions, messages } = await this.#executor.executeCalls(turn.toolCalls, {
            runContext,
            signal,
          });
          turn.setToolResults(executions);

          for (const message of messages) {
            history.push(message); // append normalized results to THIS run's copy
          }
          turn.complete(); // tool phase done — the next turn owns the model call
          this.#events.emit(RunEvents.TURN_COMPLETED, {
            runId,
            turnId: turn.id,
            data: {
              number: turn.number,
              status: turn.status,
              toolResults: summarizeToolResults(executions),
            },
          });
          continue; // next model call sees the appended tool results
        }

        if (turn.toolCalls.length === 0) {
          // Neither final nor tool calls — structurally impossible after
          // assertModelResult, guarded here as a loop invariant.
          throw new LoopError('Model produced neither final output nor tool calls.', {
            runId,
            turnId: turn.id,
          });
        }
        break; // tool calls on the final allowed turn — fall through to MaxTurnsError
      }

      // maxTurns exhausted without final output.
      throw new MaxTurnsError(
        `Run exceeded maxTurns (${this.#maxTurns}) without producing final output.`,
        { runId, maxTurns: this.#maxTurns },
      );
    } catch (cause) {
      const failure = enrich(cause, { runId });
      const interruptedTurn = markFailedTurn(turns, failure);
      if (interruptedTurn) {
        // Keep the event stream lifecycle-consistent: a turn that was opened
        // always closes, even when the loop dies mid-flight.
        this.#events.emit(RunEvents.TURN_COMPLETED, {
          runId,
          turnId: interruptedTurn.id,
          data: { number: interruptedTurn.number, status: interruptedTurn.status },
        });
      }
      const result = buildRunResult({
        runContext,
        status: 'failed',
        error: failure,
        turns,
        startedAt,
      });
      this.#events.emit(RunEvents.RUN_FAILED, {
        runId,
        data: { error: serializeFailure(failure), lastTurnNumber: turns.length },
      });
      return result;
    }
  }

  /** Emit run.completed with full structured payload. */
  #emitRunCompleted(runId, result) {
    this.#events.emit(RunEvents.RUN_COMPLETED, {
      runId,
      data: {
        output: result.output,
        turnCount: result.turns.length,
        durationMs: result.metadata.durationMs,
      },
    });
  }

  /**
   * Model seam — isolated so later phases can decorate it (retry, tracing,
   * streaming) without touching the cycle logic. The request is a defensive
   * copy: adapters cannot mutate this run's conversation state.
   * @returns {Promise<NormalizedModelResult>}
   */
  async callModel(request) {
    try {
      const result = await this.#agent.model.call(request, { signal: request.signal ?? null });
      return result;
    } catch (cause) {
      if (cause instanceof ModelError) {
        throw cause;
      }
      throw new ModelError(`Model call failed in turn ${request.metadata.turnNumber}.`, {
        runId: request.metadata.runId,
        cause,
      });
    }
  }
}

// ---------------------------------------------------------------------------
// helpers
// ---------------------------------------------------------------------------

function buildRegistryFromAgent(agent) {
  const registry = new ToolRegistry();
  for (const tool of agent.tools) {
    registry.register(tool);
  }
  return registry;
}

function validateMaxTurns(maxTurns) {
  if (!Number.isInteger(maxTurns) || maxTurns < 1) {
    throw new InputError('"maxTurns" must be an integer >= 1.', { received: maxTurns });
  }
  return maxTurns;
}

/**
 * Attach run/turn correlation onto an error without losing its identity,
 * cause chain or existing context. Non-object throwables are wrapped.
 */
function enrich(error, { runId, turnId } = {}) {
  if (error === null || typeof error !== 'object') {
    return new LoopError(String(error), { runId, turnId });
  }
  if (!('runId' in error) && runId !== undefined) {
    Object.defineProperty(error, 'runId', {
      value: runId,
      enumerable: true,
      configurable: true,
      writable: true,
    });
  }
  if (turnId !== undefined && !('turnId' in error)) {
    Object.defineProperty(error, 'turnId', {
      value: turnId,
      enumerable: true,
      configurable: true,
      writable: true,
    });
  }
  return error;
}

/** Close the still-running turn (if any) as failed; returns it for event emission. */
function markFailedTurn(turns, error) {
  const runningTurn = [...turns].reverse().find((t) => t.status === Turn.Status.RUNNING);
  if (runningTurn) {
    runningTurn.fail(error);
    return runningTurn;
  }
  return null;
}

function buildRunResult({ runContext, status, output = null, error = null, turns, startedAt }) {
  const endedAt = Date.now();
  return {
    runId: runContext.runId,
    status,
    output,
    ...(error ? { error: serializeFailure(error) } : {}),
    turns: turns.map((t) => t.snapshot()),
    lastTurn: turns.length > 0 ? turns[turns.length - 1].snapshot() : null,
    metadata: {
      agentName: runContext.agent.name,
      startedAt,
      endedAt,
      durationMs: endedAt - startedAt,
      ...runContext.metadata,
    },
  };
}

function serializeFailure(error) {
  return {
    name: error?.name ?? 'Error',
    message: error?.message ?? String(error),
    ...(error && typeof error === 'object'
      ? Object.fromEntries(
          Object.entries(error).filter(([, v]) =>
            typeof v === 'string' || typeof v === 'number' || typeof v === 'boolean'),
        )
      : {}),
  };
}

function summarizeToolResults(executions) {
  return executions.map((e) => ({
    toolName: e.call.name,
    toolCallId: e.call.id,
    status: e.status,
  }));
}

const silentLogger = { debug() {}, info() {}, warn() {}, error() {} };
