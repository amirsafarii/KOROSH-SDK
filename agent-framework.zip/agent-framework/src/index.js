/**
 * Public API surface — deliberately small.
 *
 * Exported: Agent, Tool, Runner (+ the injectable logger factory).
 * Everything else (AgentLoop, TurnRunner internals, ToolExecutor,
 * ToolRegistry, InputNormalizer, RunContext, EventBus) is internal; it is
 * reachable via deep imports for advanced hosts/tests but is not part of the
 * stable contract and may evolve between phases.
 */

// Public API
export { Agent } from './core/agent.js';
export { Tool } from './core/tool.js';
export { Runner } from './loop/runner.js';
export { createConsoleLogger, nullLogger } from './logger.js';

// Typed errors — part of the public contract for programmatic handling.
export {
  FrameworkError,
  ConfigurationError,
  InputError,
  NormalizationError,
  ModelResultError,
  ModelError,
  LoopError,
  MaxTurnsError,
  ToolError,
  ToolNotFoundError,
  ToolValidationError,
  ToolExecutionError,
  ToolResultError,
} from './errors.js';

// Internal-but-importable seams (documented in README as non-stable):
export { AgentLoop, DEFAULT_MAX_TURNS } from './loop/agent-loop.js';
export { Turn } from './loop/turn.js';
export { ToolRegistry } from './tools/registry.js';
export { ToolExecutor } from './tools/executor.js';
export { SequentialStrategy } from './tools/sequential-strategy.js';
export { normalizeInput } from './input/normalizer.js';
export { toToolMessage } from './tools/result.js';
export { RunContext } from './context/run-context.js';
export { EventBus, RunEvents } from './events/bus.js';
export { assertModelResult } from './model/types.js';
